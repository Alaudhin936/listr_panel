<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('conduct_appraisals', function (Blueprint $table) {
            $table->unsignedBigInteger('booking_appraisal_id')->nullable()->after('id');
            $table->boolean('is_draft')->default(false);
            $table->dropColumn('hotleads_id');
            $table->boolean('converted_to_just_listed')->default(false);
            $table->foreign('booking_appraisal_id')->references('id')->on('booking_appraisals')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('conduct_appraisals', function (Blueprint $table) {
               $table->dropForeign(['booking_appraisal_id']);
                $table->dropColumn(['booking_appraisal_id','is_draft','converted_to_just_listed']);
                $table->unsignedInteger('hotleads_id');
        });
    }
};
